# Email Configuration for ClotCare Emergency System
# Replace these values with your actual Gmail credentials

# Your Gmail address (the one sending emails)
EMAIL_SENDER = "aione00011001@gmail.com"

# Your Gmail app password (NOT your regular password)
# To get this: Go to Google Account settings > Security > 2-Step Verification > App passwords
EMAIL_PASSWORD = "lskq kcio lotp clvg"

# Email address to receive emergency alerts
EMAIL_RECIPIENT = "ramezelwakil@gmail.com"

# Optional: Additional recipients (comma-separated)
ADDITIONAL_RECIPIENTS = [
    # "doctor@hospital.com",
    # "emergency@clinic.com"
] 